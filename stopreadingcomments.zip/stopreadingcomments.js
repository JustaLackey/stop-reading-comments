
var comments = document.getElementsByClassName('comments');

for (var i = 0; i < comments.length; i ++) {
    comments[i].style.display = 'none';
}


var commentlink = document.getElementsByClassName('reddit-comment-link');

for (var i = 0; i < commentlink.length; i ++) {
    commentlink[i].style.display = 'none';
}

